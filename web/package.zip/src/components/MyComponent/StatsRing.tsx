import { Box, Text, Center, Group } from '@mantine/core';
import { RingProgress, rem } from '@mantine/core';
import { IconStairsUp, IconRun, IconBarbellFilled } from '@tabler/icons-react';

const icons = {
  stamina: IconStairsUp,
  speed: IconRun, 
  strength: IconBarbellFilled,
};

interface Stats {
  stamina: number;
  speed: number;
  strength: number;
}

interface StatsRingProps {
  stats: Stats;
}

export function StatsRing({ stats }: StatsRingProps) {
  const data = [
    { label: 'Strength', stats: `${stats.strength} / 100`, progress: stats.strength, color: '#74c0fc', icon: 'strength' },
    { label: 'Stamina', stats: `${stats.stamina} / 100`, progress: stats.stamina, color: '#74c0fc', icon: 'stamina' },
    { label: 'Speed', stats: `${stats.speed} / 100`, progress: stats.speed, color: '#74c0fc', icon: 'speed' },
  ];

  const statElements = data.map((stat) => {
    const Icon = icons[stat.icon];
    return (
      <Box
        key={stat.label}
        p="5px"
        style={{
          backgroundColor: '#242424',
          opacity: 0.9,
          border: 'none',
          width: '250px',
          display: 'flex',
          alignItems: 'center',
          borderRadius: 'var(--mantine-radius-md)' // Added border-radius for rounded corners
        }}
      >
        <RingProgress
          size={80}
          roundCaps
          thickness={8}
          sections={[{ value: stat.progress, color: stat.color }]}
          label={
            <Center>
              <Icon style={{ width: rem(20), height: rem(20) }} stroke={1.5} />
            </Center>
          }
        />
        <Box ml="sm">
          <Text c="dimmed" size="xs" tt="uppercase" fw={700}>
            {stat.label}
          </Text>
          <Text fw={700} size="xl">
            {stat.stats}
          </Text>
        </Box>
      </Box>
    );
  });

  return (
    <Center style={{ width: '100%' }}>
      <Group spacing="md">
        {statElements}
      </Group>
    </Center>
  );
}