import '@mantine/dates/styles.css';
import React from "react";
import "./App.css";
import MyComponent from "./MyComponent/main";

const App: React.FC = () => {
  return (
    <MyComponent />
  );
};

export default App;
